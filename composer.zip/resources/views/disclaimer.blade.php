@extends('app')
@section('title', 'Disclaimer')

@section('content')
    <section class="container">
        <p> SSSK works for humanity and social service. It only provides a link. Donors and Successful acceptors make it
            successful because of their joint effort, mutual understanding, cooperation and on their own risk.
            SSSK Shall not be responsible for any mishappening and loss of life or property.
            Managing Director
            Vinod Jkian</p>

    </section>
@endsection
