@extends('app')
@section('title', 'Dashboard')

@section('content')

@endsection
