@extends('app')
@section('title', 'About')

@section('content')

@endsection
