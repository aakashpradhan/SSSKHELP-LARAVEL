@extends('app')
@section('title', 'Profile')

@section('content')
    <section>
        <div>
            <table id="table">
                <th>
                    Name
                </th>
                <th>
                    Gender
                </th>
                <th>
                    Age
                </th>
                <th>
                    Blood Group
                </th>
                <th>
                    Address
                </th>
                <th>
                    Mobile Number
                </th>

                <tr>
                    <td>
                        Vinod JKIAN
                    </td>
                    <td>
                        Male
                    </td>
                    <td>
                        35 years
                    </td>
                    <td>
                        B+
                    </td>
                    <td>
                        Country: India,<br>
                        State/UT/Province/Region: Jammu & Kashmir,<br>
                        City District: Rajouri,<br>
                        Tehsil/Locality/Area: Sunderbani
                    </td>
                    <td>
                        9797867115
                    </td>
                </tr>
            </table>
        </div>
        div.
    </section>

@endsection
