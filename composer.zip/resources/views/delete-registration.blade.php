@extends('app')
@section('title', 'Delete Registration')

@section('content')

@endsection
