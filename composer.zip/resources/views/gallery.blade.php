@extends('app')
@section('title', 'Gallery')

@section('content')
@endsection
