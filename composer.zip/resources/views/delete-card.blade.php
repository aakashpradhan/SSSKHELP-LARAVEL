@extends('app')
@section('title', 'Delete Card')

@section('content')

@endsection
