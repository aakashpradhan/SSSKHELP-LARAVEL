@extends('app')
@section('title', 'After ')

@section('content')

@endsection
