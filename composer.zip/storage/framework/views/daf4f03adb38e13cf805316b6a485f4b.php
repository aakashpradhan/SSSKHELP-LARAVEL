
<?php $__env->startSection('title', 'General Instructions'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container">
        <ol>
            <li>
                Physical appearance of Social workers is strictly prohibited in the trust. Visitors are respectfully advised
                not to visit and enter the trust physically. They may become online members of the trust by visiting the
                official website of the trust.
            </li>
            <li>
                SSSK never accepts money or any other kind of material things donated as charity in the trust. People are as
                advised not to donate such things in the trust.
            </li>
            <li>
                Kindly don't add Your fake IDs in the list donors. Be mature and responsible. Don't play with the lives of
                emergency patients.
            </li>
            <li>
                Just after donating your blood, kindly delete your registration by visiting the official website of the
                trust. Unuseful appearance of your registration profile can create a trouble to the emergency patients. If
                you are willing for more donations than you may opt for new registration.
            </li>
            <li>
                Unhealthy donors are advised not to donate their blood. Even after repeated warnings if unhealthy donors
                donate their blood than severe health problems may happen to them.
            </li>
            <li>
                Blood donation is a Voluntarily free Social Service. Patient and their attendants are advised not to give
                money or other things to the donors for their donation.
            </li>
            <li>
                Beware of fraud and fake blood banks. All Services of SSSK are free of cost. Blood donated by voluntary
                donors may likely be misused by some greedy and irresponsible persons. All social workers are advised to be
                very careful about their donation and to be a prey of such selfish people. Donors are advised to identify
                the real patients and have direct links with them. Kindly donate your blood in the government registered
                banks only.
            </li>
            <li>
                It is the to moral duty of the society to respect and take care of all the donors.
            </li>
        </ol>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssskhelp\resources\views/general-instructions.blade.php ENDPATH**/ ?>