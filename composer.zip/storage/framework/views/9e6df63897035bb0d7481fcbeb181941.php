
<?php $__env->startSection('title', 'Profile Preview'); ?>

<?php $__env->startSection('content'); ?>
    <section id="view-profile-reg">

        <div>
            <table id="table">
                <th>
                    Name
                </th>
                <th>
                    Gender
                </th>
                <th>
                    Age
                </th>
                <th>
                    Blood Group
                </th>
                <th>
                    Address
                </th>
                <th>
                    Mobile Number
                </th>

                <tr>
                    <td>
                        <?php echo e($validatedData['name']); ?>

                    </td>
                    <td>
                        <?php echo e($validatedData['gender']); ?>

                    </td>
                    <td>
                        <?php echo e($validatedData['age']); ?> years
                    </td>
                    <td>
                        <?php echo e($validatedData['blood_group']); ?>

                    </td>
                    <td>
                        Country: <?php echo e($validatedData['country']); ?>,<br>
                        State/UT/Province/Region: <?php echo e($validatedData['state']); ?>,<br>
                        City District: <?php echo e($validatedData['district']); ?>,<br>
                        Tehsil/Locality/Area: <?php echo e($validatedData['tehsil']); ?>

                    </td>
                    <td>
                        <?php echo e($validatedData['contact']); ?>

                    </td>
                </tr>
            </table>
        </div>

        <div class="authorize">
            <p><span class="required">*</span></p>
            <input type="checkbox" name="authorize" id="" class="check" required>
            <p>I authorise this website to display my profile so that the needy could contact me as and when there is an
                emergency</p>
        </div>

        <div class="buttons">
            <form action="<?php echo e(route('register')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="button" value="Back">
                <input type="submit" value="Submit">
                <input type="button" value="Exit">
            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssskhelp\resources\views/profile-preview.blade.php ENDPATH**/ ?>