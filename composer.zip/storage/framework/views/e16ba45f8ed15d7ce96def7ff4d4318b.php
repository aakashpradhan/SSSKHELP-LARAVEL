
<?php $__env->startSection('title', 'Disclaimer'); ?>

<?php $__env->startSection('content'); ?>
    <section class="container">
        <p> SSSK works for humanity and social service. It only provides a link. Donors and Successful acceptors make it
            successful because of their joint effort, mutual understanding, cooperation and on their own risk.
            SSSK Shall not be responsible for any mishappening and loss of life or property.
            Managing Director
            Vinod Jkian</p>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ssskhelp\resources\views/disclaimer.blade.php ENDPATH**/ ?>